<?php
/****************************************************************************************************
Modified by Luke Andrews
*****************************************************************************************************
R. V. Sampangi. 2018. Solution for Server-Side Scripting Assignment 4. In INFX2670: Introduction to Server-Side Scripting, Faculty of Computer Science, Dalhousie University, NS, Canada. Used with permission.
****************************************************************************************************/
?>
<?php
	/*
	 * @file: panel.php
	 * @author: Raghav V. Sampangi
	 * @year: 2018
	 * @desc: INFX 2670 (Winter 2018): This is part of the solution for the CMS assignment series (A1-A7).
	 * @attribution: This template is named "Jumbotron".
	 * 				 It was downloaded from the Bootstrap examples website: http://getbootstrap.com/docs/4.0/examples/jumbotron/
	 */
	?>
<div class="card">
  <div class="card-header">Search Posts</div>
  <div class="card-body">
  	<form method="get" action="search_results.php">
  		<div class="form-group space-bottom">
  			<input type="text" class="form-control" name="results" placeholder="Search tags">  		
  		</div>
  		<div class="form-group">
  			<input type="radio" name="searchType" value="tags"> Tags<br>
  			<input type="radio" name="searchType" value="categories"> Categories<br>
  			<input type="radio" name="searchType" value="authors"> Authors
  		</div>
  		<div class="form-group space-top">
  			<button type="submit" class="btn btn-primary" id="submitSearch">Submit</button>
  		</div>

  	</form>
</div> 

	<?php
	if (isset($_GET['unauthAccess'])) {	
				if ($_GET['unauthAccess'] == 'true' ) {
					?>
					<div class="card-body" style="background-color: lightgrey"><p>You need to login to access the user profile</p></div>
					<?php 	}
				}
				?>
	<div class="card">
		<div class="card-header">Login to your account</div>
		<div class="card-body">
			<?php 
	/*
		UPDATE: This panel will now display the login form only for the following two cases:
		(a) Default -- there has not been an attempt to login by the user.
		(b) Error in login -- user has supplied the website with a wrong username or password (error printed below form).

		The script to process login is in header.php and functions.php

		If there is no error in login, the CMS will log the user into the system and print a "welcome" message instead
		of the form.
	*/

		if (isset($_SESSION['loggedIn'])) {
			$user_firstname = $_SESSION['firstname'];
			echo "<p class='text-primary'>Welcome, $user_firstname!</p>";

			if (isset($_SESSION['last_access'])) {
				echo "<p>You last accessed this site on: " . $_SESSION['last_access'] . "</p>";
			}
			else {
				echo "<p>This is the first time you've logged in!</p>";
			}
		}
		else {
			include "includes/loginform.php";

				if (isset($_GET['loginError'])) {
					echo "<p class='small text-danger space-top-bottom'><em>** Invalid username or password!</em></p>";
				}
			}
			?>
		</div>
	</div>
	<div class="card space-top-bottom">
		<div class="card-header">Report Issues</div>
		<div class="card-body">
			<p class="text-secondary small">Is something on this website not working? <a href="report.php">Click here to report issues</a>.</p>
		</div>
	</div>