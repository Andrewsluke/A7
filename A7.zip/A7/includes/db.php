<?php
/****************************************************************************************************
Modified by Luke Andrews
*****************************************************************************************************
R. V. Sampangi. 2018. Solution for Server-Side Scripting Assignment 4. In INFX2670: Introduction to Server-Side Scripting, Faculty of Computer Science, Dalhousie University, NS, Canada. Used with permission.
****************************************************************************************************/
?>
<?php
	/*
	 * @file: db.php
	 * @author: Raghav V. Sampangi
	 * @year: 2018
	 * @desc: INFX 2670 (Winter 2018): This is part of the solution for the CMS assignment series (A1-A7).
	 * @attribution: This template is named "Jumbotron".
	 * 				 It was downloaded from the Bootstrap examples website: http://getbootstrap.com/docs/4.0/examples/jumbotron/
	 */

	$db_host = "localhost";
	$db_username = "root";
	$db_password = "root";
	$db_name = "cms";

	$conn = new mysqli ($db_host, $db_username, $db_password, $db_name);

	if ($conn->connect_error) {
		die ("Error connecting to the DB.<br>" . $db->connect_error);
	}
	/* For debug purposes only. This is otherwise not required.
	else {
		echo "Connected!";
	}
	*/
?>