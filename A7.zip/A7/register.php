<?php
include "includes/header.php";


if (isset($_POST['reg_user'])) {
	$userfname= sanitize($_POST['first_name']);
	$userlname = sanitize($_POST['last_name']);
	$userrole = sanitize($_POST['user_role']);
	$useremail = sanitize($_POST['user_email']);
	$usern = sanitize($_POST['usern']);
	$pass1 = sanitize($_POST['pass']);
	$pass2 = sanitize($_POST['passw']);
	
	if ($_FILES['user_image']['name'] != "") {

		$image = $_FILES['user_image']['name'];
		$user_image_temp = $_FILES['user_image']['tmp_name'];
		$user_image_filesize = $_FILES['user_image']['size'];
		$target = "images/" . $image;

		$user_image_filetype = strtolower(pathinfo($target,PATHINFO_EXTENSION));
		$uploadStatus = true;

		if ($user_image_filetype != 'jpg' && $user_image_filetype != 'png') {
			$uploadStatus = false;
		}
		if ($user_image_filesize < TWO_MEGA_BYTES && $uploadStatus == true) {
			move_uploaded_file($user_image_temp, $target);
		}			
	}
	else {
		$image = "";
	}

	
	$upper = '#[A-Z]#'; //check uppercase
	$lower = '#[a-z]#'; //check lowercase
	$num = '#[0-9]#'; //check numbers
	$length = '#.+.+.+.+.+.+.+.+#'; //check length
	if ($pass1 == $pass2) {
		if (preg_match($upper, $pass1) && preg_match($lower, $pass1) && preg_match($num, $pass1) && preg_match($length, $pass1)) {
			$hash = password_hash($pass1, PASSWORD_DEFAULT);

			$sql = "SELECT username FROM login WHERE username = '{$usern}'";
			$existing = $conn->query($sql);

			$check = $existing->fetch_assoc();	

			if ($check == null) { 
				
				$sql = "INSERT INTO users(user_firstname, user_lastname, user_email, user_address, user_phone, user_role, user_image, user_date)";
				$sql .= "VALUES('$userfname','$userlname','$useremail','Not specified','Not specified','$userrole','$image', now())";
				$createUser = $conn->query($sql);

				if (!$createUser) {
					die("Error creating user " . $conn->error);
				}

				$sql = "SELECT MAX(user_id) AS newUser FROM users";
				$selectUser = $conn->query($sql);				

				$row = $selectUser->fetch_assoc();
				$uid = $row["newUser"];

				if (!$selectUser) {
					exit($conn->error . $uid);
				}

				$sql = "INSERT into login (user_id, username, password, random_salt) VALUES ('$uid', '$usern', '$hash', '541')";
				$linkUser = $conn->query($sql);  

				header("Location: index.php");
			}
		}
		else {
			header("Location: register.php?error=noReq");
		}
	}
	else {
		header("Location: register.php?error=noMatch");
	}
}
?>

<main role="main">
	<!-- "The HTML <main> element represents the main content of the <body> of a document, portion of a document, or application.
		The main content area consists of content that is directly related to, or expands upon the central topic of, a document or the central functionality of an application."
		For more information: https://developer.mozilla.org/en-US/docs/Web/HTML/Element/main 
	-->

	<!-- Main jumbotron for a primary marketing message or call to action -->
	<div class="jumbotron">
		<div class="container">
			<h1 class="display-3">ForceCMS: Register for an Account</h1>
		</div>
	</div>

	<div class="container">
		<!-- Example row of columns -->
		<div class="row">
			<div class="col-md-12">				
				<?php
				if (isset($_GET['error'])) {
					if ($_GET['error'] == 'noMatch') { ?>
						<div class="alert alert-danger">
  							<strong>Warning!</strong> Passwords entered do not match.
						</div><hr>
					<?php 
					}
					else { ?>
						<div class="alert alert-danger">
  							<strong>Warning!</strong> Password does not meet requirements. Passwords must be at least 8 characters long, as well as contain at least 1 number, capital letter, and lowercase letter.
						</div><hr>
					<?php
					}
				}
		?>
		<form action="<?php echo $currentFileName; ?>" method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="fname">First name</label>
				<input type="text" class="form-control" name="first_name" required>
			</div>
			<div class="form-group">
				<label for="lname">Last Name</label>
				<input type="text" class="form-control" name="last_name" required>
			</div>

			<div class="form-group">
				<label for="role">User role</label>
				<select class="form-control" name="user_role" required>
					<option value="1">Author</option>
					<option value="2">Subscriber</option>
				</select>
			</div>
			<div class="form-group">
				<label for="email">User email</label>
				<input type="text" class="form-control" name="user_email" required>	
			</div>
			<div class="form-group">
				<label for="username">Username</label>
				<input type="text" class="form-control" name="usern" required>	
			</div>
			<div class="form-group">
				<label for="password">Password</label>
				<input type="text" class="form-control" name="pass" required>	
			</div>
			<div class="form-group">
				<label for="password">Re-enter Password</label>
				<input type="text" class="form-control" name="passw" required>	
			</div>

			<div class="form-group col-md-3 col-no-left-padding">
				<label for="user_image">User Image</label>
				<input type="file" id="user_image" name="user_image">
			</div>

			<div class="form-group">
				<input type="submit" class="btn btn-primary" name="reg_user" value="Register">
			</div>
		</form>

	</div>
</div>

<hr>

</div> <!-- /end main container -->

</main>

<?php
include "includes/footer.php";
?>