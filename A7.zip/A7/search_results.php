<?php
include "includes/header.php"; 

?>

<main role="main">
	<!-- "The HTML <main> element represents the main content of the <body> of a document, portion of a document, or application.
		The main content area consists of content that is directly related to, or expands upon the central topic of, a document or the central functionality of an application."
		For more information: https://developer.mozilla.org/en-US/docs/Web/HTML/Element/main 
	-->

	<!-- Main jumbotron for a primary marketing message or call to action -->
	<div class="jumbotron">
		<div class="container">
			<h1 class="display-3">ForceCMS: Search Results</h1>
		</div>
	</div>

	<div class="container">
		<!-- Example row of columns -->
		<div class="row">
			<div class="col-md-9">
				<?php

				if (isset($_GET['results'])) {
				//Posts are displayed only if they are published
					$tags = sanitize($_GET['results']);
					$searchType = $_GET['searchType'];

					if ($searchType == "tags") {
						$sql = "SELECT * FROM posts WHERE post_tags LIKE '%$tags%'";
						$retrieve_posts = $conn->query($sql);
					}
					else if ($searchType == "categories") {
						$sql = "SELECT cat_id FROM category WHERE cat_title LIKE '%$tags%'";
						$retrieve_catID = $conn->query($sql);
						

						if ($retrieve_catID->num_rows > 0) {
							while ($row = $retrieve_catID->fetch_assoc()) {
								$categ_id = $row['cat_id'];
							}
							$sql = "SELECT * FROM posts WHERE post_cat_id = '$categ_id'";
							$retrieve_posts = $conn->query($sql);
						}

						
					}
					else if ($searchType == "authors") {
						$sql = "SELECT * FROM posts WHERE post_author LIKE '%$tags%'";
						$retrieve_posts = $conn->query($sql);
					}

					if ($retrieve_posts->num_rows > 0) {
						while ($row = $retrieve_posts->fetch_assoc()) {
							$post_id = $row['post_id'];
							$post_title = $row['post_title'];
							$post_author = $row['post_author'];
							$post_date = explode(" ",$row['post_date']);
							$post_image = $row['post_image'];
							$post_content = create_paragraphs_from_DBtext($row['post_content']);
							$post_status = $row['post_status']; ?>

							<article>
								<h3><a href="posts.php?p_id=<?php echo $post_id; ?>"><?php echo $post_title; ?></a></h3>
								<p class="text-secondary small space-top-bottom">Posted by <a href=""><?php echo $post_author; ?></a> on <span class="text-primary"><?php echo $post_date[0]; ?></span></p>

								<?php 
						//Show the post image only if one has been set.
								if ($post_image != "") {				
								?>
								<img class="col-md-4 col-no-left-padding" src="images/<?php echo $post_image; ?>" alt="">
								<?php
									}
								?>

							<p><?php echo $post_content; ?></p>

							<p><a class="btn btn-secondary" href="posts.php?p_id=<?php echo $post_id; ?>" role="button">View details &raquo;</a></p>
						</article>
			      <?php }
			  	    }
				} ?>

					</div>
					<div class="col-md-3">
						<?php 
						/* Panel containing the login form and report issues link */
						include "includes/panel.php"; 
						?>
					</div>
				</div>

				

			</div> <!-- /end main container -->

		</main>

		<?php include "includes/footer.php"; ?>