<?php
/****************************************************************************************************
Modified by Luke Andrews
*****************************************************************************************************
R. V. Sampangi. 2018. Solution for Server-Side Scripting Assignment 4. In INFX2670: Introduction to Server-Side Scripting, Faculty of Computer Science, Dalhousie University, NS, Canada. Used with permission.
****************************************************************************************************/
?>

<?php
	/*
	 * @file: view_posts.php
	 * @author: Raghav V. Sampangi
	 * @year: 2018
	 * @desc: INFX 2670 (Winter 2018): This is part of the solution for the CMS assignment series (A1-A7).
	 */

	include "includes/header.php"; 

	if (isset($_POST['create_user'])) {
			$fname = sanitize($_POST['first_name']);
			$lname = sanitize($_POST['last_name']);
			$email = sanitize($_POST['user_email']);
			$userna = sanitize($_POST['userna']);
			$passwo = sanitize($_POST['passwo']);
			$role = sanitize($_POST['user_role']);	
			$hash = password_hash($passwo, PASSWORD_DEFAULT);		

			if ($_FILES['image']['name'] != "") {

				$image = $_FILES['image']['name'];
				$user_image_temp = $_FILES['image']['tmp_name'];
				$user_image_filesize = $_FILES['image']['size'];
				$target = "../images/" . $image;

				$user_image_filetype = strtolower(pathinfo($target,PATHINFO_EXTENSION));
				$uploadStatus = true;

				if ($user_image_filetype != 'jpg' && $user_image_filetype != 'png') {
					$uploadStatus = false;
				}
				if ($user_image_filesize < TWO_MEGA_BYTES && $uploadStatus == true) {
					move_uploaded_file($user_image_temp, $target);
				}			
			}
			else {
				$image = "";
			}

			$sql = "SELECT username FROM login WHERE username = '{$userna}'";
			$existing = $conn->query($sql);

			$ree = $existing->fetch_assoc();	

			if ($ree == null) { 
				
				$sql = "INSERT INTO users(user_firstname, user_lastname, user_email, user_address, user_phone, user_role, user_image, user_date)";
				$sql .= "VALUES('$fname','$lname','$email','Not specified','Not specified','$role','$image', now())";
				$createUser = $conn->query($sql);

				$sql = "SELECT MAX(user_id) AS newUser FROM users";
				$selectUser = $conn->query($sql);				

				$row = $selectUser->fetch_assoc();
				$uid = $row["newUser"];

				if (!$selectUser) {
					exit($conn->error . $uid);
				}

				$sql = "INSERT into login (user_id, username, password, random_salt) VALUES ('$uid', '$userna', '$hash', '541')";
				$linkUser = $conn->query($sql);  

			}			
		}

	if (isset($_GET['add_user'])) {
		include "includes/add_user.php";
		
	}
	else {

		if (isset($_POST['admin_updateUser'])) {
			$fname = sanitize($_POST['firstname']);
			$lname = sanitize($_POST['lastname']);
			$email = sanitize($_POST['email']);
			$username = sanitize($_POST['username']);
			$password = sanitize($_POST['password']);
			$role = sanitize($_POST['role']);
			$uid = $_GET['u_id'];

			if ($_FILES['image']['name'] != "") {

				$image = $_FILES['image']['name'];
				$user_image_temp = $_FILES['image']['tmp_name'];
				$user_image_filesize = $_FILES['image']['size'];
				$target = "../images/" . $image;

				$user_image_filetype = strtolower(pathinfo($target,PATHINFO_EXTENSION));
				$uploadStatus = true;

				if ($user_image_filetype != 'jpg' && $user_image_filetype != 'png') {
					$uploadStatus = false;
				}
				if ($user_image_filesize < TWO_MEGA_BYTES && $uploadStatus == true) {
					move_uploaded_file($user_image_temp, $target);
				}			
			}
			else {
				$image = "";
			}


			$sql = "UPDATE users SET user_firstname = '$fname' WHERE user_id = $uid";
			$update = $conn->query($sql);

			$sql = "UPDATE users SET user_lastname = '$lname' WHERE user_id = $uid";
			$update = $conn->query($sql);

			$sql = "UPDATE users SET user_email = '$email' WHERE user_id = $uid";
			$update = $conn->query($sql);

			$sql = "UPDATE users SET user_role = '$role' WHERE user_id = $uid";
			$update = $conn->query($sql);

			if ($image != "") {
				$sql = "UPDATE users SET user_image = '$image' WHERE user_id = $uid";
				$update = $conn->query($sql);
			}	

			$sql = "UPDATE login SET username = '$username' WHERE user_id = $uid";
			$update = $conn->query($sql);

			$sql = "UPDATE login SET password = '$password' WHERE user_id = $uid";
			$update = $conn->query($sql);

		}


		?>

		<main role="main">
			<!-- Main jumbotron for a primary marketing message or call to action -->
			<div class="jumbotron">
				<div class="container">
					<h1 class="display-3">ForceCMS Admin: User Management</h1>
				</div>
			</div>

			<div class="container">
				<div class="row">
					<div class="col-md-12">

						<?php
						if (isset($_GET['source'])) {
							if ($_GET['source'] == 'edit_user') {
								include 'includes/edit_user.php';
							}
						}
						else {
							include 'includes/view_all_users.php';
						}
						?>

					</div>
				</div>
			</div>
		</main>

		<?php } include "includes/footer.php"; ?>
		<?php
		ob_end_flush();
		?>