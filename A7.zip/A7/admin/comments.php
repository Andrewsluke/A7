<?php 

	include "includes/header.php";


?>

<div class="jumbotron">
	<div class="container">
		<h1 class="display-3">ForceCMS Admin: Comments</h1>
	</div>
</div>

<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th>Comment ID</th>
			<th>Post Title</th>
			<th>Comment Author</th>
			<th>Comment Email</th>
			<th>Comment Content</th>
			<th>Date</th>
			<th>Status</th>
			<th>Approve/Delete</th>
		</tr>
	</thead>
	<tbody>

		<?php
	if (isset($_SESSION['role'])) { 

		if ($_SESSION['role'] == 0) {
				$sql = "SELECT * FROM comments";
				$select_all_comments = $conn->query($sql);
				while ($row = $select_all_comments->fetch_assoc()) {
				$comment_id = $row['comment_id'];
				$comment_post_id = $row['comment_post_id'];
				$comment_author = $row['comment_author'];
				$comment_email = $row['comment_email'];
				$comment_content = $row['comment_content'];
				$comment_date = $row['comment_date'];
				$comment_status = $row['comment_status'];

				$getPost = "SELECT post_title FROM posts WHERE post_id = {$comment_post_id}";
				$getTitle = $conn->query($getPost);

				while ($row =$getTitle->fetch_assoc()) {
					$post_title = $row['post_title'];
				}

				echo "<tr>";
				echo "<td>{$comment_id}</td>";
				echo "<td>{$post_title}</td>";
				echo "<td>{$comment_author}</td>";
				echo "<td>{$comment_email}</td>";
				echo "<td>{$comment_content}</td>";
				echo "<td>{$comment_date}</td>";
				echo "<td>{$comment_status}</td>";
				echo "<td><a href='{$currentFileName}?source=approve&com_id={$comment_id}' class='btn btn-success'>Approve</a>&nbsp;&nbsp;";
				echo "<a href='{$currentFileName}?delete_com={$comment_id}' class='btn btn-danger'>Delete</a></td>";
				echo "</tr>";
				
			}
		}
		elseif ($_SESSION['role'] == 1) {

			$author = $_SESSION['username'];
			$sql = "SELECT * FROM posts WHERE post_author = '{$author}'";

			$getPostIDs = $conn->query($sql);
			while ($row = $getPostIDs->fetch_assoc()) {
				$postID = $row['post_id'];

				$sql = "SELECT * FROM comments WHERE comment_post_id = {$postID}";
				$select_all_comments = $conn->query($sql);

				while ($row = $select_all_comments->fetch_assoc()) {
				$comment_id = $row['comment_id'];
				$comment_post_id = $row['comment_post_id'];
				$comment_author = $row['comment_author'];
				$comment_email = $row['comment_email'];
				$comment_content = $row['comment_content'];
				$comment_date = $row['comment_date'];
				$comment_status = $row['comment_status'];

				$getPost = "SELECT post_title FROM posts WHERE post_id = {$comment_post_id}";
				$getTitle = $conn->query($getPost);

				while ($row =$getTitle->fetch_assoc()) {
					$post_title = $row['post_title'];
				}

				echo "<tr>";
				echo "<td>{$comment_id}</td>";
				echo "<td>{$post_title}</td>";
				echo "<td>{$comment_author}</td>";
				echo "<td>{$comment_email}</td>";
				echo "<td>{$comment_content}</td>";
				echo "<td>{$comment_date}</td>";
				echo "<td>{$comment_status}</td>";
				echo "<td><a href='{$currentFileName}?approve={$comment_id}' class='btn btn-success'>Approve</a>&nbsp;&nbsp;";
				echo "<a href='{$currentFileName}?delete_com={$comment_id}' class='btn btn-danger'>Delete</a></td>";
				echo "</tr>";
				
			}
			}


		}
			
			$select_all_comments = $conn->query($sql);

			
	}
		?>

	</tbody>
	</table>

	<?php
		if(isset($_GET['delete_com'])) {
			$delete_this_comment = $_GET['delete_com'];

			$sql = "DELETE FROM comments WHERE comment_id = {$delete_this_comment}";
			$delete_comment_status = $conn->query($sql);

			if (!$delete_comment_status) {
				die ("<p>Sorry. Could not delete comment.</p>" . $conn->connect_error);
			}
			else {
				/************************************************************************************
				  Because this is a GET query and the page has already loaded, the removed category
				  might still be showing in the table.
				  For this, you need to "refresh" or "reload" the page. We do so using the header()
				  function.
				 ************************************************************************************/
				header("Location: comments.php");
			}
		}

		if (isset($_GET['approve'])) {
			$approve_this_comment = $_GET['approve'];

			$sql = "UPDATE comments SET comment_status = 'approved' WHERE comment_id = {$approve_this_comment}";
			$approving_comment = $conn->query($sql);

			if (!$approving_comment) {
				die ("<p>Sorry, could not approve this comment.</p>" . $conn->connect_error);
			}
			else {
				header("Location: comments.php");
			}
		}

		include "includes/footer.php";
	?>