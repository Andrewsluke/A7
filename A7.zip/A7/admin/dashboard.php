 <?php
 include "includes/header.php";
 $dayago = date("Y-m-d H:m:s", strtotime('-24 hours'));

 ?>


 <main role="main">

		<div class="jumbotron">
			<div class="container">
				<h1 class="display-3">ForceCMS Admin: Your Dashboard</h1>
			</div>
		</div>
	<div class="container">	
		<div class="row">

			<div class="col-md-4"> 
				<div class="card">
  					<div class="card-header"><strong>Recent Posts</strong></div>
  						<div class="card-body">
  							<?php
  							if ($_SESSION['role'] == 0) {
								$sql = "SELECT * FROM posts WHERE post_date > '{$dayago}'";
							}
							elseif ($_SESSION['role'] == 1) {
								$author = $_SESSION['username'];
								$sql = "SELECT * FROM posts WHERE post_date > '{$dayago}' AND post_author = '{$author}'";
							}

						$select_all_posts = $conn->query($sql);
						if (isset($select_all_posts)) { ?>
							<a class="btn btn-info" href="view_posts.php"><strong>Posts <span class="badge"><?php echo $select_all_posts->num_rows ?></span></strong></a>
						<?php	
						}
						else { ?>
							<a class="btn btn-info" href="view_posts.php">Posts <span class="badge">0</span></a>
						<?php
							
						} ?>

					</div>
				</div>
			</div>

			<div class="col-md-4"> 
				<div class="card">
  					<div class="card-header"><strong>Recent Comments</strong></div>
  						<div class="card-body">
  							<?php

  							if ($_SESSION['role'] == 0) {
								$sql = "SELECT * FROM comments WHERE comment_date > '{$dayago}'";

								$select_all_comments = $conn->query($sql);

								if ($select_all_comments) { ?>
									
									<a class="btn btn-info" href="comments.php"><strong>Comments <span class="badge"><?php echo $select_all_comments->num_rows; ?></span></strong></a>
								<?php
								}
							}					
							
							elseif ($_SESSION['role'] == 1) {
								$author = $_SESSION['username'];
								$sql = "SELECT * FROM posts WHERE post_author = '{$author}'";
								$counter = 0;
								$getPostIDs = $conn->query($sql);
								while ($row = $getPostIDs->fetch_assoc()) {
									$postID = $row['post_id'];

									$sql = "SELECT * FROM comments WHERE comment_date > '{$dayago}' AND comment_post_id = '{$postID}'";
									$select_all_comments = $conn->query($sql);

								if ($select_all_comments->num_rows > 0) { 
									$counter += $select_all_comments->num_rows;
								}
								} ?>
								<a class="btn btn-info" href="comments.php"><strong>Comments <span class="badge"><?php echo $counter ?></span></strong></a>
								<?php

							}

							 ?>

					</div>
				</div>


			</div>
			<div class="col-md-4">
				<div class="card">
  					<div class="card-header"><strong>Recent Users</strong></div>
  						<div class="card-body">
  							<?php

  							if ($_SESSION['role'] == 0) {
								$sql = "SELECT * FROM users WHERE user_date > '{$dayago}'";
							
							
								$select_all_users = $conn->query($sql);



								if ($select_all_users->num_rows > 0) {  ?>
									<a class="btn btn-info" href="view_users.php"><strong>Users <span class="badge"><?php echo $select_all_users->num_rows; ?></span></strong></a> <?php
								}			
							}
							else { ?>
								<a class="btn btn-info" href="#"><strong>Unauthorized to view users</strong></a>
							<?php
							}
							?>

					</div>
				</div>

			</div>
	</div>
</div>


<?php
include "includes/footer.php";
?>	