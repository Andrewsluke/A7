<?php
/****************************************************************************************************
Modified by Luke Andrews
*****************************************************************************************************
R. V. Sampangi. 2018. Solution for Server-Side Scripting Assignment 4. In INFX2670: Introduction to Server-Side Scripting, Faculty of Computer Science, Dalhousie University, NS, Canada. Used with permission.
****************************************************************************************************/
?>

<?php
	/*
	 * @file: view_posts.php
	 * @author: Raghav V. Sampangi
	 * @year: 2018
	 * @desc: INFX 2670 (Winter 2018): This is part of the solution for the CMS assignment series (A1-A7).
	 */

	include "includes/header.php"; 

	

?>

	<main role="main">
	<!-- Main jumbotron for a primary marketing message or call to action -->
		<div class="jumbotron">
			<div class="container">
				<h1 class="display-3">ForceCMS Admin: Post Management</h1>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col-md-12">
					
				<?php
					if (isset($_GET['source'])) {
						if ($_GET['source'] == 'edit_post') {
							include 'includes/edit_post.php';
						}
					}
					else {
						include 'includes/view_all_posts.php';
					}
				?>

				</div>
			</div>
		</div>
	</main>

<?php include "includes/footer.php"; ?>
<?php
	ob_end_flush();
?>