<?php
	
	include '../includes/db.php';

	$sql = "SELECT password, user_id FROM login";
	$passwords = $conn->query($sql);

	if ($passwords->num_rows > 0) {
		while ($row = $passwords->fetch_assoc()) {			
			$pass = $row['password'];						
			$pattern = '#^\$2y\$10\$#';

			if (!preg_match($pattern, $pass)) {

				$userID = $row['user_id'];
				$hash = password_hash($pass, PASSWORD_DEFAULT);
				$sql = "UPDATE login SET password = '$hash' WHERE user_id = $userID";
				$update = $conn->query($sql);

				if (!$update) {
					die($conn->error);
				}
			}
		}
	}
	header("Location: profile.php?enc=1");
 ?>