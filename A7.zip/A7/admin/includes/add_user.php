<?php
/****************************************************************************************************
Modified by Luke Andrews
*****************************************************************************************************
R. V. Sampangi. 2018. Solution for Server-Side Scripting Assignment 4. In INFX2670: Introduction to Server-Side Scripting, Faculty of Computer Science, Dalhousie University, NS, Canada. Used with permission.
****************************************************************************************************/

?>

<main role="main">
	<!-- "The HTML <main> element represents the main content of the <body> of a document, portion of a document, or application.
		The main content area consists of content that is directly related to, or expands upon the central topic of, a document or the central functionality of an application."
		For more information: https://developer.mozilla.org/en-US/docs/Web/HTML/Element/main 
	-->

	<!-- Main jumbotron for a primary marketing message or call to action -->
	<div class="jumbotron">
	<div class="container">
		<h1 class="display-3">ForceCMS Admin: Add User</h1>
	</div>
	</div>

	<div class="container">
	<!-- Example row of columns -->
		<div class="row">
			<div class="col-md-12">				

				<form action="<?php echo $currentFileName; ?>" method="post" enctype="multipart/form-data">
					<div class="form-group">
						<label for="fname">First name</label>
						<input type="text" class="form-control" name="first_name" required>
					</div>
					<div class="form-group">
						<label for="lname">Last Name</label>
						<input type="text" class="form-control" name="last_name" required>
					</div>

					<div class="form-group">
						<label for="role">User role</label>
						<input type="text" class="form-control" name="user_role" required>
					</div>

					<div class="form-group">
						<label for="email">User email</label>
						<input type="text" class="form-control" name="user_email" required>	
					</div>
					<div class="form-group">
						<label for="username">Username</label>
						<input type="text" class="form-control" name="userna" required>	
					</div>
					<div class="form-group">
						<label for="password">Password</label>
						<input type="text" class="form-control" name="passwo" required>	
					</div>

					<div class="form-group col-md-3 col-no-left-padding">
						<label for="user_image">User Image</label>
						<input type="file" id="image" name="image">
					</div>

					<div class="form-group">
						<input type="submit" class="btn btn-primary" name="create_user" value="Create user">
					</div>
				</form>

			</div>
		</div>

		<hr>

	</div> <!-- /end main container -->

</main>
