<?php
/****************************************************************************************************
Modified by Luke Andrews
*****************************************************************************************************
R. V. Sampangi. 2018. Solution for Server-Side Scripting Assignment 4. In INFX2670: Introduction to Server-Side Scripting, Faculty of Computer Science, Dalhousie University, NS, Canada. Used with permission.
****************************************************************************************************/
?>
<?php
$sql = "SELECT * FROM users WHERE user_id = {$_SESSION['user_id']}";
$userinfo = $conn->query($sql);

if (!$userinfo) {
	die ("<p>Sorry. Your request could not be completed.</p>" . $conn->connect_error);
}
else {
	while ($row = $userinfo->fetch_assoc()) {				
		$user_firstname = $row['user_firstname'];
		$user_lastname = $row['user_lastname'];
		$user_email = $row['user_email'];
		$user_address = $row['user_address'];
		$user_phone = $row['user_phone'];
		$user_role = $row['user_role'];
		$user_image = $row['user_image'];
	}	
}	
?>
<div class="container">
	<!-- Example row of columns -->
	<div class="row">
		<div class="col-md-1"></div>
		<div class="col-md-10">
			<h3 class="display-4 text-primary">Edit Profile</h3>
			<hr>

			<form>
				<div class="form-group">
					<label>Username</label>
					<input disabled type="text" class="form-control" name="firstname" value="<?php if(isset($_SESSION['username'])) { echo $_SESSION['username']; } else { echo ''; } ?>">
				</div>						
				<div class="form-group">
					<label>First Name</label>
					<input disabled type="text" class="form-control" name="firstname" value="<?php if(isset($user_firstname)) { echo $user_firstname; } else { echo ''; } ?>">
				</div>
				<div class="form-group">
					<label>Last Name</label>
					<input disabled type="text" class="form-control" name="lastname" value="<?php if(isset($user_lastname)) { echo $user_lastname; } else { echo ''; } ?>">
				</div>
				<div class="form-group">
					<label>Email</label>
					<input disabled type="text" class="form-control" name="email" value="<?php if(isset($user_email)) { echo $user_email; } else { echo ''; } ?>">
				</div>
				<div class="form-group">
					<label>Address</label>
					<input disabled type="text" class="form-control" name="address" value="<?php if(isset($user_address)) { echo $user_address; } else { echo ''; } ?>">
				</div>
				<div class="form-group">
					<label>Phone</label>
					<input disabled type="text" class="form-control" name="phone" value="<?php if(isset($user_phone)) { echo $user_phone; } else { echo ''; } ?>">
				</div>
				<div class="form-group">
					<label>Role</label>
					<input disabled type="text" class="form-control" name="role" value="<?php if(isset($user_role)) { echo $user_role; } else { echo ''; } ?>">
				</div>
				<div class="form-group col-md-3 col-no-left-padding">
				<label for="user_image">User Image</label>
				<?php 
					if($user_image != "") { 
						echo "<br><img width='100' src='../images/{$user_image}' alt='thumbnails'><br><br>"; 
					} 
					else { 
						echo "<br>No Image Assigned Yet<br>"; 
					} 
				?>
				</div>

				<div class="form-group">
					<a class='btn btn-info' href='profile.php?edit=true'>Edit User</a>							
				</div>
			</form>

		</div>
		<div class="col-md-1"></div>
	</div>
</div>

