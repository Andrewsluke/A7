<?php
/****************************************************************************************************
Modified by Luke Andrews
*****************************************************************************************************
R. V. Sampangi. 2018. Solution for Server-Side Scripting Assignment 4. In INFX2670: Introduction to Server-Side Scripting, Faculty of Computer Science, Dalhousie University, NS, Canada. Used with permission.
****************************************************************************************************/
?>
<?php
	/*
	 * @file: header.php
	 * @author: Raghav V. Sampangi
	 * @year: 2018
	 * @desc: INFX 2670 (Winter 2018): This is part of the solution for the CMS assignment series (A1-A7).
	 * @attribution: This template is named "Jumbotron".
	 * 				 It was downloaded from the Bootstrap examples website: http://getbootstrap.com/docs/4.0/examples/jumbotron/
	 */

	session_start();

	ob_start();		// Start output buffer, in case you don't know when you might need to call header() function.

	

	require_once "../includes/db.php";

	require_once "../includes/functions.php";

	const TWO_MEGA_BYTES = 2097152;



	$currentFileName = basename($_SERVER['PHP_SELF']);

	/*
	 * When we submit a form using the POST method, it loads the page that is specified in "action" attribute
	 * of the HTML form. However, when this happens, we lose the variables that we had passed in the URL
	 * to indicate which category ID needs to be updated. Since an UPDATE query would need an identifier to 
	 * update a table, we need the category ID information even after the form was submitted.
	 * To avoid such issues, we use $_SERVER['QUERY_STRING']. This retrieves the variables in the URL, i.e.
	 * whatever we pass as key=value pairs in the URL after a question mark (?).
	 * E.g. Suppose the URL was http://localhost/cms/categories.php?update_category=9  
	 *      $_SERVER['PHP_SELF'] returns "/cms/categories.php"
	 *      $_SERVER['QUERY_STRING'] returns "update_category=9"
	 *
	 * There are several other things the $_SERVER superglobal can do. Check it out on php.net
	 */
	$variables_in_URL = $_SERVER['QUERY_STRING'];



	if (session_status()) {	
		if($currentFileName == "profile.php") { //ACCESSING PROFILE.PHP
			if(!isset($_SESSION['loggedIn'])) {						
				header("Location: ../index.php" . "?unauthAccess=true");	
			}
		}
		else {				
			if(isset($_SESSION['role'])) { //subscribers trying to access other admin pages
				if ($_SESSION['role'] == 2) {
					header("Location: ../index.php");
				}
			}
			else {
				header("Location: ../index.php" . "?unauthAccess=true");
			}
		}
	}

	if ($currentFileName == "view_users.php") {
		if ($_SESSION['role'] != 0 ) {
			header("Location: ../index.php");
		}
	}

	/* Function call that submits the category to the database */
	if (isset($_POST['add_category'])) {
		$cat_title = $_POST['cat_title'];

		insert_category($cat_title);
	}


	if (isset($_POST['save_updates'])) { //edit profile
		$fname = sanitize($_POST['firstname']);
		$lname = sanitize($_POST['lastname']);
		$email = sanitize($_POST['email']);
		$address = sanitize($_POST['address']);
		$phone = sanitize($_POST['phone']);
		$role = sanitize($_POST['role']);
		if ($_FILES['image']['name'] != "") {

			$image = $_FILES['image']['name'];
			$user_image_temp = $_FILES['image']['tmp_name'];
			$user_image_filesize = $_FILES['image']['size'];
			$target = "../images/" . $image;

			$user_image_filetype = strtolower(pathinfo($target,PATHINFO_EXTENSION));
			$uploadStatus = true;

			if ($user_image_filetype != 'jpg' && $user_image_filetype != 'png') {
				$uploadStatus = false;
			}
			if ($user_image_filesize < TWO_MEGA_BYTES && $uploadStatus == true) {
				move_uploaded_file($user_image_temp, $target);
			}			
		}
		else {
			$image = "";
		}
	
		$uid = $_SESSION['user_id'];

		$sql = "UPDATE users SET user_firstname = '$fname' WHERE user_id = $uid";
		$update = $conn->query($sql);

		$sql = "UPDATE users SET user_lastname = '$lname' WHERE user_id = $uid";
		$update = $conn->query($sql);

		$sql = "UPDATE users SET user_email = '$email' WHERE user_id = $uid";
		$update = $conn->query($sql);

		$sql = "UPDATE users SET user_address = '$address' WHERE user_id = $uid";
		$update = $conn->query($sql);

		$sql = "UPDATE users SET user_phone = '$phone' WHERE user_id = $uid";
		$update = $conn->query($sql);

		$sql = "UPDATE users SET user_role = '$role' WHERE user_id = $uid";
		$update = $conn->query($sql);

		
		$sql = "UPDATE users SET user_image = '$image' WHERE user_id = $uid";
		$update = $conn->query($sql);
	}

	/* Statements that Update the category in the database */
	if (isset($_POST['update_this_cat'])) {
		$cat_title_to_be_updated = htmlspecialchars(stripslashes(trim($_POST['updated_cat_title'])));
		$cat_id_to_be_updated = $_GET['update_category'];

		$sql = "UPDATE category SET cat_title = '$cat_title_to_be_updated' WHERE cat_id = $cat_id_to_be_updated";

		$result_update_category = $conn->query($sql);

		if (!$result_update_category) {
			die("<p><em>Sorry, could not update category!</em></p>" . $conn->error);
		}
		else {
			/************************************************************************************
			 * This is important because it reloads the page, and does not show 
			 * the ID of the updated category in the address bar, after it has been updated.
			 ************************************************************************************/
			header("Location: categories.php");
		}
	}


	/* Delete a category when the "delete" button is pressed */
	if (isset($_GET['delete_category'])) {
		$delete_this_category = $_GET['delete_category'];

		$delete_cat_status = delete_category($delete_this_category);

		if ($delete_cat_status) {
			//Because this is a GET query and the page has already loaded, the removed category
			//might still be showing in the table.
			//To update the HTML table being displayed, you need to "refresh" or "reload" the page. 
			//We do so using the header() function.
			/************************************************************************************
			 * This is important because it reloads the page, and does not show 
			 * the ID of the deleted category in the address bar, after it has been deleted.
			 ************************************************************************************/
			header("Location: categories.php");
		}
	}

				
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- This favicon is downloaded/used from the Dalhousie website (https://www.dal.ca), accessible through the URL set as the value of HREF -->
	<link rel="icon" href="https://cdn.dal.ca/etc/designs/dalhousie/clientlibs/global/default/images/favicon/favicon.ico.lt_cf5aed4779c03bd30d9b52d875efbe6c.res/favicon.ico">

	<title>ForceCMS</title>

	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<!-- Custom styles for this template -->
	<link href="../css/jumbotron.css" rel="stylesheet">

	<!-- CDN links for Google's Material Icon set -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

	<!-- Custom styles for this assignment solution -->
	<link href="../css/forceUI.css" rel="stylesheet">
</head>

<body>
	<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
		<a class="navbar-brand" href="../index.php">ForceCMS</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarsExampleDefault">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item <?php if ($currentFileName == 'index.php') { echo "active"; } ?>">
				<a class="nav-link" href="../index.php">Home <span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item <?php if ($currentFileName == 'posts.php') { echo "active"; } ?>">
				<a class="nav-link" href="../posts.php">Posts</a>
				</li>
				<li class="nav-item <?php if ($currentFileName == 'report.php') { echo "active"; } ?>">
				<a class="nav-link" href="../report.php">Report Issues</a>
				</li>
				<li class="nav-item <?php if ($currentFileName == 'register.php') { echo "active"; } ?>">
				<a class="nav-link" href="../register.php">Register</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Categories</a>
					<div class="dropdown-menu">

					<?php
							$sql = "SELECT * FROM category";
							$categories_query_result = $conn->query($sql);

							if ($categories_query_result->num_rows > 0) {
								while ($row = $categories_query_result->fetch_assoc()) {
									$cat_id = $row['cat_id'];
									$cat_title = $row['cat_title'];

									echo "<a class='dropdown-item' href='../category_post.php?c_id=$cat_id'>$cat_title</a>";
								}
							}
							else {
								echo "No categories exist yet.";
							}
					?>
					</div>
				</li>
				<?php
					if (isset($_SESSION['role'])) {
						if (($_SESSION['role'] == 0) || ($_SESSION['role'] == 1)) {
							echo "<li class='nav-item'><a class='nav-link' data-toggle='collapse' data-target='#control-panel' href='#'>Control Panel</a></li>";
						}
					}
				?>
			</ul>


			<!-- User Profile -->
			<?php if(isset($_SESSION['loggedIn'])) {

				if ($currentFileName == 'profile.php') { ?>
					<ul class="navbar-nav pull-right">
						<li class="nav-item">
							<a href="../index.php" target="_blank" class="nav-link" role="button" aria-haspopup="true" aria-expanded="false">View Your Site</a>
						</li>
					</ul>				
				<?php
				}
				$usermenu1 = <<<_END
				<ul class="navbar-nav pull-right">
					<li class="nav-item dropdown">
						<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
_END;
			
			if (isset($_SESSION['role']) && $_SESSION['role'] != 2) {
				$usermenu2 = <<<_END
						<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li>
								<a class="dropdown-item" href="dashboard.php">Dashboard</a>
							</li>
							<li>								
								<a class='dropdown-item' href="profile.php">Profile</a>
							</li>
							<li>
								<a class='dropdown-item' href="includes/logout.php">Log Out</a>
							</li>
						</ul>
					</li>
				</ul>
_END;
			}
			else if (isset($_SESSION['role']) && $_SESSION['role'] == 2) {
				$usermenu2 = <<<_END
						<b class="caret"></b></a>
						<ul class="dropdown-menu">							
							<li>
								<a class='dropdown-item' href="profile.php">Profile</a>
							</li>
							<li>
								<a class='dropdown-item' href="includes/logout.php">Log Out</a>
							</li>
						</ul>
					</li>
				</ul>
_END;

			}

				echo $usermenu1 . $_SESSION['firstname'] . " " . $_SESSION['lastname'] . $usermenu2;
			}
			?>


			<?php /*
			<form class="form-inline my-2 my-lg-0">
				<input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
				<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
			</form>
			*/ ?>

			
		</div>
	</nav>



	<div id="control-panel" class="collapse">

	<!-- List of Admin-only/Author-only navigation items -->
		<?php
		if ($_SESSION['role'] == 0) { 
			//Nav for Admin only
		?>

		<div class="nav-scroller bg-white box-shadow">
			<nav class="nav nav-underline">
				<a class="nav-link active text-info" href="#"><strong>Admin Control Panel</strong></a>
				<a class="nav-link" href="dashboard.php">Dashboard</a>
				<ul class="navbar-nav">
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Posts</a>
						<div class="dropdown-menu">
							<a class='dropdown-item' href='view_posts.php'>View All Posts</a>
							<a class='dropdown-item' href='add_post.php'>Add Post</a>
						</div>
					</li>
				</ul>
				<a class="nav-link" href="categories.php">Categories</a>
				<a class="nav-link" href="profile.php">Profile</a>
				<a class="nav-link" href="comments.php">Comments</a>
				<ul class="navbar-nav">
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Users</a>
						<div class="dropdown-menu">
							<a class='dropdown-item' href='view_users.php'>View All Users</a>
							<a class='dropdown-item' href='view_users.php<?php echo "?add_user=true";?>'>Add New User</a>
						</div>
					</li>
				</ul>
			</nav>
		</div>

		<?php
		}
		elseif ($_SESSION['role'] == 1) { 
			//Nav for Author only
		?>

		<div class="nav-scroller bg-white box-shadow">
			<nav class="nav nav-underline">
				<a class="nav-link active text-info" href="#"><strong>Author Control Panel</strong></a>
				<a class="nav-link" href="dashboard.php">Dashboard</a>			
				<ul class="navbar-nav">
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Posts</a>
						<div class="dropdown-menu">
							<a class='dropdown-item' href='view_posts.php'>View All Posts</a>
							<a class='dropdown-item' href='add_post.php'>Add Post</a>
						</div>
					</li>
				</ul>
				<a class="nav-link" href="categories.php">Categories</a>
				<a class="nav-link" href="profile.php">Profile</a>
				<a class="nav-link" href="comments.php">Comments</a>
			</nav>
		</div>

		<?php
		}

	?>
	</div>
