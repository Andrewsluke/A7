<?php
/****************************************************************************************************
Modified by Luke Andrews
*****************************************************************************************************
R. V. Sampangi. 2018. Solution for Server-Side Scripting Assignment 4. In INFX2670: Introduction to Server-Side Scripting, Faculty of Computer Science, Dalhousie University, NS, Canada. Used with permission.
****************************************************************************************************/
?>

<?php
	/*
	 * @file: view_all_posts.php
	 * @author: Raghav V. Sampangi
	 * @year: 2018
	 * @desc: INFX 2670 (Winter 2018): This is part of the solution for the CMS assignment series (A1-A7).
	 */

?>

	<table class="table table-bordered table-hover">
		<thead>
			<tr>
				<th>Image</th>
				<th>Username</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
				<th>Role</th>				
				<th>Modify/Delete</th>
			</tr>
		</thead>
		<tbody>

		<?php

			$sql = "SELECT * FROM users";			
			$select_all_users = $conn->query($sql);

			while ($row = $select_all_users->fetch_assoc()) {
				$user_image = $row['user_image'];
				$user_id = $row['user_id'];
				$user_fname = $row['user_firstname'];
				$user_lname = $row['user_lastname'];
				$user_email = $row['user_email'];
				$user_role = $row['user_role'];
				
				$sql = "SELECT username FROM login WHERE user_id = $user_id";
				$username = $conn->query($sql);

				while ($row = $username->fetch_assoc()) {
					$user = $row['username'];
				

				echo "<tr>";
				echo "<td>";
				if($user_image != "") { 
					echo "<br><img width='100' src='../images/{$user_image}' alt='thumbnails'><br><br>"; 
				} 
				else { 
					echo "No Image Assigned"; 
				}
				echo "</td>";
				echo "<td>{$user}</td>";	
				echo "<td>{$user_fname}</td>";
				echo "<td>{$user_lname}</td>";				
				echo "<td>{$user_email}</td>";
				echo "<td>{$user_role}</td>";				
				echo "<td><a href='{$currentFileName}?source=edit_user&u_id={$user_id}' class='btn btn-primary'>Edit</a>&nbsp;&nbsp;";
				echo "<a href='{$currentFileName}?delete_user={$user_id}' class='btn btn-danger'>Delete</a></td>";
				echo "</tr>";
			}
			}
		?>

		</tbody>
	</table>

	<?php
		if(isset($_GET['delete_user'])) {
			$delete_this_user = $_GET['delete_user'];

			$sql = "DELETE FROM login WHERE user_id = {$delete_this_user}";
			$delete_user = $conn->query($sql);

			$sql = "DELETE FROM users WHERE user_id = {$delete_this_user}";
			$delete_user = $conn->query($sql);

			if (!$delete_user) {
				die ("<p>Sorry. Could not delete post.</p>" . $conn->connect_error);
			}
			else {
				/************************************************************************************
				  Because this is a GET query and the page has already loaded, the removed category
				  might still be showing in the table.
				  For this, you need to "refresh" or "reload" the page. We do so using the header()
				  function.
				 ************************************************************************************/
				header("Location: view_users.php");
			}
		}
	?>