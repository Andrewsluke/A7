<?php
/****************************************************************************************************
Modified by Luke Andrews
*****************************************************************************************************
R. V. Sampangi. 2018. Solution for Server-Side Scripting Assignment 4. In INFX2670: Introduction to Server-Side Scripting, Faculty of Computer Science, Dalhousie University, NS, Canada. Used with permission.
****************************************************************************************************/
?>
<?php
	/*
	 * @file: footer.php
	 * @author: Raghav V. Sampangi
	 * @year: 2018
	 * @desc: INFX 2670 (Winter 2018): This is part of the solution for the CMS assignment series (A1-A7).
	 * @attribution: This template is named "Jumbotron".
	 * 				 It was downloaded from the Bootstrap examples website: http://getbootstrap.com/docs/4.0/examples/jumbotron/
	 */
?>
		<footer class="footer">
			<div class="container">
				<p>&copy; Luke Andrews 2018</p>
			</div>
		</footer>

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

		<!-- Bootstrap core JavaScript
		================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	</body>
</html>
