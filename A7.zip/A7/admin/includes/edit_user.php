<?php
/****************************************************************************************************
Modified by Luke Andrews
*****************************************************************************************************
R. V. Sampangi. 2018. Solution for Server-Side Scripting Assignment 4. In INFX2670: Introduction to Server-Side Scripting, Faculty of Computer Science, Dalhousie University, NS, Canada. Used with permission.
****************************************************************************************************/
?>

<?php 
	/*
	 * @file: edit_post.php
	 * @author: Raghav V. Sampangi
	 * @year: 2018
	 * @desc: INFX 2670 (Winter 2018): This is part of the solution for the CMS assignment series (A1-A7).
	 */
?>
	
<div class="container">
	<!-- Example row of columns -->
	<div class="row">
		<div class="col-md-1"></div>
		<div class="col-md-10">

			<?php

			if (isset($_GET['u_id'])) {
			$sql = "SELECT * FROM users WHERE user_id = {$_GET['u_id']}";
			$userinfo = $conn->query($sql);
			$u_id = $_GET['u_id'];
			if (!$userinfo) {
				die ("<p>Sorry. Your request could not be completed.</p>" . $conn->connect_error);
			}
			else {
				while ($row = $userinfo->fetch_assoc()) {				
					$user_firstname = $row['user_firstname'];
					$user_lastname = $row['user_lastname'];
					$user_role = $row['user_role'];
					$user_email = $row['user_email'];
					$user_image = $row['user_image'];

					$sql = "SELECT username, password FROM login WHERE user_id = {$_GET['u_id']}";
					$user = $conn->query($sql);
					while ($row = $user->fetch_assoc()) {
						$username = $row['username'];
						$password = $row['password'];
					}

					
				}	
			}
			?>
			
			<form action="<?php echo $currentFileName . "?u_id=" . $u_id; ?>" method="post" enctype="multipart/form-data">
										
				<div class="form-group">
					<label for="firstname">First Name</label>
					<input type="text" class="form-control" name="firstname" value="<?php if(isset($user_firstname)) { echo $user_firstname; } else { echo ''; } ?>">
				</div>
				<div class="form-group">
					<label for="lastname">Last Name</label>
					<input type="text" class="form-control" name="lastname" value="<?php if(isset($user_lastname)) { echo $user_lastname; } else { echo ''; } ?>">
				</div>				
				<div class="form-group">
					<label for="role">Role</label>
					<input type="text" class="form-control" name="role" value="<?php if(isset($user_role)) { echo $user_role; } else { echo ''; } ?>">
				</div>
				<div class="form-group">
					<label for="email">Email</label>
					<input type="text" class="form-control" name="email" value="<?php if(isset($user_email)) { echo $user_email; } else { echo ''; } ?>">
				</div>
				<div class="form-group">
					<label for="username">Username</label>
					<input type="text" class="form-control" name="username" value="<?php if(isset($username)) { echo $username; } else { echo ''; } ?>">
				</div>
				<div class="form-group">
					<label for="password">Password</label>
					<input type="text" class="form-control" name="password" value="<?php if(isset($password)) { echo $password; } else { echo ''; } ?>">
				</div>
				<div class="form-group col-md-3 col-no-left-padding">
				<label for="user_image">User Image</label>
				<?php 
					if($user_image != "") { 
						echo "<br><img width='100' src='../images/{$user_image}' alt='thumbnails'><br><br>"; 
					} 
					else { 
						echo "<br>No Image Assigned Yet<br>"; 
					} 
				?>

				<input type="file" id="image" name="image">
				</div>

				<div class="form-group">												
					<input type="submit" class="btn btn-primary" name="admin_updateUser" value="Save Updates">					
				</div>
			</form> 

		</div>
	</div>
</div>

<?php } ?>
