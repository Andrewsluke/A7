<?php
/****************************************************************************************************
Modified by Luke Andrews
*****************************************************************************************************
R. V. Sampangi. 2018. Solution for Server-Side Scripting Assignment 4. In INFX2670: Introduction to Server-Side Scripting, Faculty of Computer Science, Dalhousie University, NS, Canada. Used with permission.
****************************************************************************************************/
?>

<?php
	/*
	 * @file: profile.php
	 * @author: Raghav V. Sampangi
	 * @year: 2018
	 * @desc: INFX 2670 (Winter 2018): This is part of the solution for the CMS assignment series (A1-A7).
	 */
	include "includes/header.php"; 
	?>

	<main role="main">

		<div class="jumbotron">
			<div class="container">
				<h1 class="display-3">ForceCMS Admin: Your Profile</h1>
			</div>
		</div>
		<div class="row">
		<div class="col-md-4"> </div>
		<div class="col-md-4"> </div>
		<div class="col-md-4">
			<?php
			if (isset($_GET['enc'])) {
				?>
				<a type="button" class="btn btn-info" href="secure_all_passwords.php">PASSWORDS SECURED</a> <?php
			} 
			else if (isset($_SESSION['role'])) {
				if ($_SESSION['role'] == 0) {
					?>
					<a type="button" class="btn btn-info" href="secure_all_passwords.php">SECURE ALL PASSWORDS</a>
					<?php						
				}
			}
			?>
		</div>
		</div>

		<?php 
		if (isset($_GET['edit'])) {
			if ($_GET['edit'] =="true") { 
				include "includes/edit_profile.php";	
			}
				
		}
		else {
			include "includes/view_profile.php";
		}


		?>
			
		
</main>
<?php include "includes/footer.php"; ?>